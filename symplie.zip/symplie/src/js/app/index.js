'use strict';

var app = angular.module('SymplieApp', ['ngSanitize']);

require('./directives');
require('./controllers');
require('./filters');